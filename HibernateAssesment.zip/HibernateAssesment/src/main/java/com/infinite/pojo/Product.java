package com.infinite.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author saikirangud
 *
 */
@Entity
@Table(name = "Product")
public class Product {
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;

	@Column(name = "ProductName")
	private String ProductName;

	@Column(name = "Price")
	private int Price;

	@Column(name = "Quantity")
	private int Quantity;

	@Column(name = "SubTotal")
	private int SubTotal;

	public Product() {
		// super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProductName() {
		return ProductName;
	}

	public void setProductName(String productName) {
		ProductName = productName;
	}

	public int getPrice() {
		return Price;
	}

	public void setPrice(int price) {
		Price = price;
	}

	public int getQuantity() {
		return Quantity;
	}

	public void setQuantity(int quantity) {
		Quantity = quantity;
	}

	public int getSubTotal() {
		return SubTotal;
	}

	public void setSubTotal(int subTotal) {
		SubTotal = subTotal;
	}

}
