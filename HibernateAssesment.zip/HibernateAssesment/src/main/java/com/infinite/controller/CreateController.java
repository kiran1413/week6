package com.infinite.controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.infinite.impl.ProductImpl;
import com.infinite.pojo.Product;

/**
 * @author saikirangud
 *
 */
@Controller 
public class CreateController {
	private ApplicationContext con;
		@RequestMapping(value="/insert",method=RequestMethod.POST)
		public String insert(@ModelAttribute("bean") Product e,Model m){
			con=new ClassPathXmlApplicationContext("ApplicationContext.xml");
			ProductImpl obj=con.getBean("dao",ProductImpl.class);
			obj.saveData(e);

			String ProductName=e.getProductName();
			int Price=e.getPrice();
			int Quantity=e.getQuantity();
			int SubTotal=e.getSubTotal();
			//Session sessionobj = sessionFactory;
			m.addAttribute("msg",ProductName); 
			System.out.println("i");
			return "insert";	
		}

	 

	}

